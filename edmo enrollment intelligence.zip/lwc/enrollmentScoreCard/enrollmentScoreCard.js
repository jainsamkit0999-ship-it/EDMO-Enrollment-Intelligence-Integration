import { LightningElement, api, wire } from 'lwc';
import getLatestScore from '@salesforce/apex/EnrollmentScoreCardController.getLatestScore';

export default class EnrollmentScoreCard extends LightningElement {
    @api recordId; // Contact Id, auto-populated on a Contact record page

    scoreData;
    error;

    @wire(getLatestScore, { contactId: '$recordId' })
    wiredScore({ data, error }) {
        if (data) {
            this.scoreData = data;
            this.error = undefined;
        } else if (error) {
            this.error = this.extractErrorMessage(error);
            this.scoreData = undefined;
        }
    }

    get hasScore() {
        return this.scoreData != null;
    }

    get hasError() {
        return this.error != null;
    }

    get showEmptyState() {
        return !this.hasScore && !this.hasError;
    }

    get badgeClass() {
        const tier = this.scoreData ? this.scoreData.tier : '';
        if (tier === 'Hot') return 'badge badge-hot';
        if (tier === 'Warm') return 'badge badge-warm';
        return 'badge badge-cold';
    }

    get badgeIcon() {
        const tier = this.scoreData ? this.scoreData.tier : '';
        if (tier === 'Hot') return '🔴';
        if (tier === 'Warm') return '🟠';
        return '🔵';
    }

    get formattedScoredAt() {
        if (!this.scoreData || !this.scoreData.scoredAt) {
            return '';
        }
        return new Date(this.scoreData.scoredAt).toLocaleString();
    }

    extractErrorMessage(error) {
        if (error && error.body && error.body.message) {
            return error.body.message;
        }
        return 'An error occurred while loading the enrollment score.';
    }
}
