/**
 * Thin trigger: delegates all logic to EnrollmentScoreTriggerHandler so the
 * trigger body itself contains no business logic and no SOQL/DML.
 */
trigger EnrollmentScoreTrigger on Enrollment_Score__c (after insert) {
    if (Trigger.isAfter && Trigger.isInsert) {
        EnrollmentScoreTriggerHandler.handleAfterInsert(Trigger.new);
    }
}
